#!/bin/bash
# Helix Installation Script

INSTALL_DIR="${INSTALL_DIR:-/usr/local/bin}"
ARCH=$(uname -m)
OS=$(uname -s | tr '[:upper:]' '[:lower:]')

# Determine the correct binary
case "$OS" in
    linux)
        case "$ARCH" in
            x86_64) BINARY="helix_x86_64_unknown_linux_gnu" ;;
            aarch64) BINARY="helix_aarch64_unknown_linux_gnu" ;;
            *) echo "Unsupported architecture: $ARCH"; exit 1 ;;
        esac
        ;;
    darwin)
        case "$ARCH" in
            x86_64) BINARY="helix_x86_64_apple_darwin" ;;
            arm64) BINARY="helix_aarch64_apple_darwin" ;;
            *) echo "Unsupported architecture: $ARCH"; exit 1 ;;
        esac
        ;;
    *)
        echo "Unsupported OS: $OS"
        exit 1
        ;;
esac

if [[ -f "releases/$BINARY" ]]; then
    echo "Installing $BINARY to $INSTALL_DIR/helix"
    sudo cp "releases/$BINARY" "$INSTALL_DIR/helix"
    sudo chmod +x "$INSTALL_DIR/helix"
    echo "Helix installed successfully!"
else
    echo "Binary not found: releases/$BINARY"
    exit 1
fi
